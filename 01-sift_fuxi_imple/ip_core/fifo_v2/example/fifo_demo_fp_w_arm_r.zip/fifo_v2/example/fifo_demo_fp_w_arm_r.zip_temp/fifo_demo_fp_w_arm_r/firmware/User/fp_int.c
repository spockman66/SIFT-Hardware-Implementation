#include <stdio.h>
#include <string.h>
#include "cmem7_includes.h"


extern uint32_t is_prog_FULL;
extern uint32_t is_prog_EMPTY;
extern uint32_t is_almost_FULL;
extern uint32_t is_almost_EMPTY;
extern uint32_t is_FULL;
extern uint32_t is_EMPTY;

/*extern BOOL isDone;

void DMAC_IRQHandler(void) {
	if (DMA_GetIntStatus(DMA_Int_TfrComplete)) {
		// TODO :
		isDone = TRUE;
		
		DMA_ClearInt(DMA_Int_TfrComplete);
	}
	
	if (DMA_GetIntStatus(DMA_Int_Err)) {
		// TODO :
		DMA_ClearInt(DMA_Int_Err);
	}
}*/

void FP0_IRQHandler(void)
{

	uint32_t cmdAddrIntStatusReg = 0xc0000030;
	uint32_t cmdAddrIntEnableReg = 0xc0000020;
	uint32_t cmdAddrWrCntReg = 0xc0000028;
	uint32_t cmdAddrRdCntReg = 0xc000002c;
	uint32_t cmdAddrRtrlReg = 0xc000001c;
	
	uint32_t int_status;
	uint32_t wrcnt;
	uint32_t rdcnt;
	
	
	*((volatile uint32_t *)cmdAddrRtrlReg) = 0x0; // disable interrupt get from FP
	int_status = *((volatile uint32_t *)cmdAddrIntStatusReg);
	
 if((int_status >>5)& 0x1 == 0x1)
	{
		is_prog_EMPTY = 1;
		*((volatile uint32_t *)cmdAddrIntEnableReg) = 0x1f;	
		wrcnt = *((volatile uint32_t *)cmdAddrWrCntReg);
		rdcnt = *((volatile uint32_t *)cmdAddrRdCntReg);
		printf("\n Now the FIFO status is prog_rempty, wrcnt:%x,rdcnt:%x\n", wrcnt, rdcnt);	

	}
	
	else if((int_status >>1)& 0x1 == 0x1)
	{
		is_EMPTY = 1;
		*((volatile uint32_t *)cmdAddrIntEnableReg) = 0x1d;
		wrcnt = *((volatile uint32_t *)cmdAddrWrCntReg);
		rdcnt = *((volatile uint32_t *)cmdAddrRdCntReg);
		printf("\n Now the FIFO status is rempty, wrcnt:%x,rdcnt:%x\n", wrcnt, rdcnt);
	}
	
	
	else if((int_status >>3)& 0x1 == 0x1)
	{
		is_almost_EMPTY = 1;
		*((volatile uint32_t *)cmdAddrIntEnableReg) = 0x17;
		wrcnt = *((volatile uint32_t *)cmdAddrWrCntReg);
		rdcnt = *((volatile uint32_t *)cmdAddrRdCntReg);
		printf("\n Now the FIFO status is almost_rempty, wrcnt:%x,rdcnt:%x\n", wrcnt, rdcnt);
	
	}
	
	
 else if((int_status >>4)& 0x1 == 0x1)
	{
		
		is_prog_FULL = 1;
		*((volatile uint32_t *)cmdAddrIntEnableReg) = 0x2f;
		wrcnt = *((volatile uint32_t *)cmdAddrWrCntReg);
		rdcnt = *((volatile uint32_t *)cmdAddrRdCntReg);
		printf("\n Now the FIFO status is prog_full, wrcnt:%x,rdcnt:%x\n", wrcnt, rdcnt);
    
	}
	
 else if((int_status >>2)& 0x1 == 0x1)
	{
		is_almost_FULL = 1;
		*((volatile uint32_t *)cmdAddrIntEnableReg) = 0x2b;
		wrcnt = *((volatile uint32_t *)cmdAddrWrCntReg);
		rdcnt = *((volatile uint32_t *)cmdAddrRdCntReg);
		printf("\n Now the FIFO status is almwost_full, wrcnt:%x,rdcnt:%x\n", wrcnt, rdcnt);
	}
 
	
	else if(int_status & 0x1 == 0x1)
	{
		is_FULL = 1;
		*((volatile uint32_t *)cmdAddrIntEnableReg) = 0x2a;
		wrcnt = *((volatile uint32_t *)cmdAddrWrCntReg);
		rdcnt = *((volatile uint32_t *)cmdAddrRdCntReg);
		printf("\n Now the FIFO status is wfull:wrcnt:%x,rdcnt:%x\n", wrcnt, rdcnt);
	}
	
	*((volatile uint32_t *)cmdAddrRtrlReg) = 0x1; // enable interrupt get from FP

}
