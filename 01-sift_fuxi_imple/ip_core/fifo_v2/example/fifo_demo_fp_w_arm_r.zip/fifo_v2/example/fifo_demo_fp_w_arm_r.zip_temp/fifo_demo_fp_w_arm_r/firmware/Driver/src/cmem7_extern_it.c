#include "cmem7_includes.h"

extern BOOL isDone;

void DMAC_IRQHandler(void) {
	if (DMA_GetIntStatus(DMA_Int_TfrComplete)) {
		// TODO :
		isDone = TRUE;
		
		DMA_ClearInt(DMA_Int_TfrComplete);
	}
	
	if (DMA_GetIntStatus(DMA_Int_Err)) {
		// TODO :
		DMA_ClearInt(DMA_Int_Err);
	}
}



