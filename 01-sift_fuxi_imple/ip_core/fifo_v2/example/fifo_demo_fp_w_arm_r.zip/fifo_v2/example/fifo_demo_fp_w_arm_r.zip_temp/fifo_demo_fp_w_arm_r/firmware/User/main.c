/**
  * This case is used to move data by DMA and FP, from and to DDRC
	* Hardware :
  **/
	
#include <stdio.h>
#include <string.h>
#include "cmem7_includes.h"



int main(void)
{
	{
	  UART_InitTypeDef init;
	
		init.UART_BaudRate = 115200;
		init.UART_StopBits = UART_StopBits_1; 
		init.UART_Parity = UART_Parity_None;  
		init.UART_LoopBack = FALSE;
		init.UART_RxEn = FALSE; 
		init.UART_CtsEn = FALSE;	
		UART_Init(UART2, &init);
		UART_Enable(UART2, TRUE);
		
		GPIO_Init(GPIO_GROUP_GPIO, 0xFFFFFFFF);
	  GPIO_EnableOutput(GPIO_GROUP_GPIO, 0xFFFFF1FF);
	}

  printf("\n\n/******************************\\\n");
	printf("Init done !!!\n");

	

if (1) { //test FP1 slave FIFO space, fp as write, arm as read.
		uint32_t srcAddr = 0xc0000000;
		uint32_t cmdAddrStatusReg = 0xc0000024;
		uint32_t cmdAddrRdCntReg = 0xc000002c;
		uint32_t addr;
		uint32_t i, j,data, refData, tmp1, tmp2,gpio_value;
		
		uint32_t status;
		uint32_t  rdcnt;

		i=0;
		addr = srcAddr;
		
		printf("\nTest external FP1 slave FIFO space, and wait for FIFO being FULL !\n");
	
    gpio_value = GPIO_Read(GPIO_GROUP_GPIO);
		gpio_value = (gpio_value >> 9)& 0x00000007;
		if (gpio_value == 0x5) { 
		   printf("Now, FP write done ! ARM begins to read !\n");
		}
		

		addr = srcAddr;
		j = srcAddr;
		for(i=0; i<512; i++) {
			tmp1 = ~j;
			tmp2 = j;
			refData = ((tmp1 << 25) & 0xf8000000) | ((tmp1 << 16) & 0x07fc0000) | ((tmp2 << 7) & 0x0003fe00) | ((tmp2 >> 2) & 0x000001ff);
			data = *((volatile uint32_t *)addr);
			status = *((volatile uint32_t *)cmdAddrStatusReg);
			rdcnt = *((volatile uint32_t *)cmdAddrRdCntReg);
		
			printf("Read 0x%x, then status_r:%x,rdcnt_r:%x\n", addr,status,rdcnt);
			if (data != refData) {
				printf("ARM read FP1-slave FAILED @0x%x: 0x%x!=0x%x!\n", addr, data, refData);
				//while (1);
			}
			j += 4;
			
		}
		printf("ARM read done and compare the data is OK !\n");
	}
}
