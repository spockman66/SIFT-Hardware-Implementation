#ifndef __REG_WR__
#define __REG_WR__

#define R_FLS_REG_BASE   0x40800000
#define FLS_CTRL0        (R_FLS_REG_BASE + 0x00)
#define FLS_CTRL1        (R_FLS_REG_BASE + 0x04)
#define FLS_TRIGGER      (R_FLS_REG_BASE + 0x08)
#define FLS_STATUS       (R_FLS_REG_BASE + 0x0c)
#define FLS_DATA         (R_FLS_REG_BASE + 0x10)

// void wr_dut_reg (unsigned int addr , unsigned int data) ;
// unsigned int rd_dut_reg (unsigned int addr , unsigned int *data) ;

void wr_dut_reg (unsigned long addr , unsigned long data) ;
unsigned int rd_dut_reg (unsigned long addr , unsigned long *data) ;


// int flash_indirect_rd_alfull(unsigned int fls_rw_cnt,unsigned char fls_cs_high,unsigned char fls_clk_div,unsigned long fls_addr,unsigned char fls_command,
//                       unsigned char trsp_en, unsigned char trsp_rd_en, unsigned char fls_op_clean, unsigned char fls_op_start,
//                       unsigned long rw_init_value,unsigned char erase_enable);


// int flash_indirect_wr_alempty(unsigned int fls_rw_cnt,unsigned char fls_cs_high,unsigned char fls_clk_div,unsigned long fls_addr,unsigned char fls_command,
//                       unsigned char trsp_en, unsigned char trsp_rd_en, unsigned char fls_op_clean, unsigned char fls_op_start,unsigned long rw_init_value);

// unsigned char flash_indirect_rd(unsigned int fls_rw_cnt,unsigned char fls_cs_high,unsigned char fls_clk_div,unsigned long fls_addr,unsigned char fls_command,
//                       unsigned char trsp_en, unsigned char trsp_rd_en, unsigned char fls_op_clean, unsigned char fls_op_start,
//                       unsigned long rw_init_value,unsigned char erase_enable);

// int flash_indirect_wr(unsigned int fls_rw_cnt,unsigned char fls_cs_high,unsigned char fls_clk_div,unsigned long fls_addr,unsigned char fls_command,
//                       unsigned char trsp_en, unsigned char trsp_rd_en, unsigned char fls_op_clean, unsigned char fls_op_start,unsigned long rw_init_value);

// int wrsr(unsigned int fls_rw_cnt,unsigned char fls_cs_high,unsigned char fls_clk_div,unsigned long fls_addr,unsigned char fls_command,
//          unsigned int wrsr_value, unsigned char trsp_en, unsigned char trsp_rd_en, unsigned char fls_op_clean, unsigned char fls_op_start);

// unsigned long rd_fls_data(unsigned int fls_rw_cnt,unsigned char fls_cs_high,unsigned char fls_clk_div,unsigned long fls_addr,unsigned char fls_command,
//                        unsigned char trsp_en, unsigned char trsp_rd_en, unsigned char fls_op_clean, unsigned char fls_op_start);

// unsigned long rd_fls_data1(unsigned int fls_rw_cnt);

// int send_flash_command(unsigned int fls_rw_cnt,unsigned char fls_cs_high,unsigned char fls_clk_div,unsigned long fls_addr,unsigned char fls_command,
//                        unsigned char trsp_en, unsigned char trsp_rd_en, unsigned char fls_op_clean, unsigned char fls_op_start);






#endif
