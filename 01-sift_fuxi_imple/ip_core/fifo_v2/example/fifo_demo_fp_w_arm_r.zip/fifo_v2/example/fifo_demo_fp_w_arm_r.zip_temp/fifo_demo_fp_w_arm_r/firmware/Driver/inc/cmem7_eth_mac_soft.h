//================================================================================
// Copyright (c) 2012 Capital-micro, Inc.(Beijing)  All rights reserved.
//
// Capital-micro, Inc.(Beijing) Confidential.
//
// No part of this code may be reproduced, distributed, transmitted,
// transcribed, stored in a retrieval system, or translated into any
// human or computer language, in any form or by any means, electronic,
// mechanical, magnetic, manual, or otherwise, without the express
// written permission of Capital-micro, Inc.
//
//================================================================================
// File Description: 
// Header file for Ethernet MAC soft IP in M7A
//================================================================================
// Revision History :
//     V1.0   2013-04-11  FPGA IP Grp, first created
//     V1.1   2013-10-15  FPGA IP Grp, PHY Configuration & Status Read modified
//     V2.0   2014-01-20  FPGA IP Grp, modify architecture of transmitting & receiving
//                                     buffer, only support M7A                                  
//================================================================================

#ifndef __CMEM7_SoftEthernetMAC_H 
#define __CMEM7_SoftEthernetMAC_H 

#define BASE_ADDR_SOFT_MAC 0xa0000000

#define REG(n,a) *((volatile int*)(BASE_ADDR_SOFT_MAC + n*0x2000 + a))
// #define REG(n,a) *((volatile int*)(BASE_ADDR_SOFT_MAC + n*0x20000000 + a))
//******************************************************************
//                 Address Declaration
//******************************************************************
#define MAC_CFG_ADDR          0x1000 
#define FRAME_FILTER_ADDR     0x1004
#define PHY_ADDR_ADDR         0x1008
#define PHY_DATA_ADDR         0x100c
#define FLOW_CTRL_ADDR        0x1010
#define VLAN_TAG_ADDR         0x1014
#define MAC_ADDR_H_ADDR       0x101c
#define MAC_ADDR_L_ADDR       0x1020

#define MEM_CONFIG_ADDR       0x1040 
#define MEM_STATUS_ADDR       0x1044 
#define TRANS_STATUS_ADDR     0x1048 
#define RCV_LEN_ADDR          0x104C   
#define RCV_STATUS_ADDR       0x1050 

#define MAC_CFG(n)            REG(n,MAC_CFG_ADDR) 
#define FRAME_FILTER(n)       REG(n,FRAME_FILTER_ADDR) 
#define PHY_ACCESS_ADDR(n)    REG(n,PHY_ADDR_ADDR) 
#define PHY_ACCESS_DATA(n)    REG(n,PHY_DATA_ADDR) 
#define FLOW_CTRL(n)          REG(n,FLOW_CTRL_ADDR) 
#define VLAN_TAG(n)           REG(n,VLAN_TAG_ADDR) 
#define MAC_ADDR_H(n)         REG(n,MAC_ADDR_H_ADDR) 
#define MAC_ADDR_L(n)         REG(n,MAC_ADDR_L_ADDR) 

#define MEM_CONFIG(n)         REG(n,MEM_CONFIG_ADDR) 
#define MEM_STATUS(n)         REG(n,MEM_STATUS_ADDR) 
#define TRANS_STATUS(n)       REG(n,TRANS_STATUS_ADDR) 
#define RCV_LEN(n)            REG(n,RCV_LEN_ADDR) 
#define RCV_STATUS(n)         REG(n,RCV_STATUS_ADDR) 

//******************************************************************
//             PHY Register Declaration
//******************************************************************
#define  PHY_ADDR          7
#define  PHY_CTRL_ADDR     0
#define  PHY_STATUS_ADDR   1
#define  PHY_10_100_ADDR   4
#define  PHY_AN_ADDR       6
#define  PHY_1000_ADDR     10
#define  PHY_SPEED_DUPLEX_ADDR     17
#define  CSR_CLK_DV        5   // 0: clk/42;  1: clk/62;  2: clk/16;  3: clk/26;  4: clk/102;  5: clk/124;

//*****************************************************************
// Function Prototype Section
//*****************************************************************
// Function name: void PhyRegWrite(unsigned char ucPhyAddr,
//	                                unsigned char ucPhyRegAddr,
//                                  unsigned char ucClkDivide,
//              		  			        unsigned int uiDataToWrite,
//              			  		        unsigned char ucDeviceID)
// Description:   Write data to PHY register
// Parameters:
// 						    unsigned char ucPhyAddr    : PHY address
//							  unsigned char ucPhyRegAddr : PHY register address
//							  unsigned char ucClkDivide  : PHY configuration clock division   
//							  unsigned int  uiDataToWrite: data to write 
//                unsigned char ucDeviceID   : channel ID
//	Returns:          
//******************************************************************
void PhyRegWrite(unsigned char ucPhyAddr,unsigned char ucPhyRegAddr,
					       unsigned char ucClkDivide,unsigned int uiDataToWrite,
                 unsigned char ucDeviceID); 

//*****************************************************************
// Function Prototype Section
//*****************************************************************
// Function name: unsigned int PhyRegRead(unsigned char ucPhyAddr,
//	                                        unsigned char ucPhyRegAddr,
//              					                  unsigned char ucClkDivide,
//              					                  unsigned char ucDeviceID)
// Description:   Read data to PHY register
// Parameters:
// 						    unsigned char ucPhyAddr    : PHY address
//							  unsigned char ucPhyRegAddr : PHY register address
//							  unsigned char ucClkDivide  : PHY configuration clock division   
//                unsigned char ucDeviceID   : channel ID
// Returns:      data read from PHY register 
//******************************************************************
unsigned int PhyRegRead(unsigned char ucPhyAddr,unsigned char ucPhyRegAddr,
					              unsigned char ucClkDivide,unsigned char ucDeviceID);

//*****************************************************************
// Function Prototype Section
//*****************************************************************
// Function name: unsigned char LinkCheck(unsigned char ucDeviceID)
// Description:   Check link is up or down
// Parameters:
//                unsigned char ucDeviceID   : channel ID
// Returns:       Link status
//	 					    1-up       0-down 
//******************************************************************
unsigned char LinkCheck(unsigned char ucDeviceID);

//*****************************************************************
// Function Prototype Section
//*****************************************************************
// Function name: void gclock_switch(unsigned char channel,
//	                                 unsigned char ucDeviceID)   
// Description:   choose clock source(hardware) for link speed
// Parameters:
//                unsigned char channel : 0-10/100M    1-1000M 
//                unsigned char ucDeviceID   : channel ID
// Note:          link speed parameter '0' and '1' choose depends on
//                RTL logic
//******************************************************************
void gclock_switch(unsigned char channel,unsigned char ucDeviceID);

//*****************************************************************
// Function Prototype Section
//*****************************************************************
// Function name: 	void PhyMannualSpeedDuplexSet(unsigned char ucSpeed,
//                                                unsigned char ucDuplex,
//                                                unsigned char ucDeviceID)                                
// Description:   	mannually set the speed and duplex status of PHY
//                  For general application, users do not need mannually configure
//                  the speed & duplex status
//                  unsigned char ucDeviceID: channel ID
// Parameters:
//                  unsigned char ucSpeed   : 0-1000M    1-100M    2-10M
//							    unsigned char ucDuplex  : 1-full-duplex   0-half-duplex
//******************************************************************
void PhyMannualSpeedDuplexSet(unsigned char ucSpeed,unsigned char ucDuplex,
					               unsigned char ucDeviceID);

//*****************************************************************
// Function Prototype Section
//*****************************************************************
// Function name: 	void PhyInitial(unsigned char *ucANst,
//                                  unsigned char *ucSpeedSt,
//                                  unsigned char *ucDuplexSt,
//                                  unsigned char ucDeviceID)
// Description:   	PHY initialization, initiate PHY auto-negotiation
//	                get status of full/half duplex and speed
// Parameters:
// 						      unsigned char *ucANst        : 1-link partner auto-negotiation able   0-disable
//							    unsigned char *ucSpeedSt     : Link speed status
//							      4:  1-support 1000BASE-T
//							      2:  1-support 100BASE-Tx
//							      1:  1-support 10BASE-T
//                  unsigned char *ucDuplexSt    : Link duplex status
//							      1:  full-duplex
//							      0:  half-duplex
//                  unsigned char ucDeviceID: channel ID
// Returns:          1-Link is up and PHY initialization is finished
//	                  0-Link is down, user should initializa the PHY again
//******************************************************************
unsigned char PhyInitial(unsigned char *ucANst,unsigned char *ucSpeedSt,
					          unsigned char *ucDuplexSt,unsigned char ucDeviceID);

//*****************************************************************
// Function Prototype Section
//*****************************************************************
// Function name: 	void MACCtrlInitial(unsigned char ucSpeed,
//	                     					      unsigned char ucDuplex,
//													            unsigned char ucTransEn,
//													            unsigned char ucRcvEn,
//													            unsigned char ucLoopBack,
//													            unsigned char ucACS,
//	                     					      unsigned char ucDeviceID);
// Description:   	Configure MAC
// Parameters:
//                  unsigned char ucSpeed   : 1-10/100BASE   0-1000BASE
//							    unsigned char ucDuplex  : 1-full         0-half
//							    unsigned char ucTransEn : 1-enable       0-disable
//							    unsigned char ucRcvEn   : 1-enable       0-disable
//							    unsigned char ucLoopBack: 1-enable       0-disable
//							    unsigned char ucACS     : 1-strip CRC/Padding   0-do not strip
//                  unsigned char ucCST     : 1-strip CRC    0-do not strip(Type frame)
//                  unsigned char ucDeviceID: channel ID
// Returns:
//******************************************************************
void MACCtrlInitial(unsigned char ucSpeed,unsigned char ucDuplex,
		      		      unsigned char ucTransEn,unsigned char ucRcvEn,
						        unsigned char ucLoopBack,unsigned char ucACS,
						        unsigned char ucCST,unsigned char ucDeviceID);

//*****************************************************************
// Function Prototype Section
//*****************************************************************
// Function name: 	void MACAddressInitial (unsigned char *mac_addr
//	                                        unsigned char ucDeviceID);
// Description:   	set MAC address
// Parameters:
//                  unsigned char *mac_addr : 6-bytes
//                  unsigned char ucDeviceID: channel ID
// Returns:
//******************************************************************
void MACAddressInitial(unsigned char *mac_addr,unsigned char ucDeviceID);

//******************************************************************
// Function name: 	void FrameRcvFilterInitial(
//						      unsigned char ucRvcAll,
//						      unsigned char ucVLANFilterEn,
//						      unsigned char ucPassCtrl
//								  unsigned char ucDisBroadcast,
//								  unsigned char ucPassMulticast,
//						      unsigned char ucDeviceID);
// Description:   	Ethernet MAC filter setting
// Parameters:
//			            unsigned char ucRvcAll       : 1-receive all frames   0-receive frames that pass DA filter
//			            unsigned char ucVLANFilterEn : 1-VLAN Tag filter enable   0-filter disable
//                  unsigned char ucPassCtrl     : 1-receive control frame    0-drop control frame
//	    						unsigned char ucDisBroadcast : 1-disable broadcast frame reception    0-enable
//			    				unsigned char ucPassMulticast: 1-receive multicast frame  0-do not receive
//                  unsigned char ucDeviceID     : channel ID
// Returns:	
//******************************************************************
void FrameRcvFilterInitial(unsigned char ucRvcAll,unsigned char ucVLANFilterEn,unsigned char ucPassCtrl,
					                 unsigned char ucDisBroadcast,unsigned char ucPassMulticast,
									         unsigned char ucDeviceID);

//******************************************************************
// Function name: 	void FlowCtrlInitial(unsigned char ucFlowCtrlRcvEn,						   
//						                           unsigned char ucFlowCtrlTransEn,
//						                           unsigned char ucDeviceID);
// Description:   	Flow control frame transmission/reception enable/disable setting
// Parameters:
//			            unsigned char ucFlowCtrlRcvEn	  : 1-enable flow control frame reception  0-diaable
//                  unsigned char ucFlowCtrlTransEn : 1-enable flow control frame transmission  0-diaable
//                  unsigned char ucDeviceID        : channel ID
// Returns:	
//******************************************************************
void FlowCtrlInitial(unsigned char ucFlowCtrlRcvEn,unsigned char ucFlowCtrlTransEn,
		      			     unsigned char ucDeviceID);

//******************************************************************
// Function name: 	void VLANTagInitial(unsigned int TagData,unsigned char ucDeviceID)
// Description:   	VLAN Tag setting
// Parameters:       
//                  unsigned int TagData    : VLAN Tag	
//                  unsigned char ucDeviceID: channel ID
// Returns: 
//******************************************************************
void VLANTagInitial(unsigned int TagData,unsigned char ucDeviceID);

//******************************************************************
// Function name: 	unsigned char FlowCtrlTransmit(unsigned char ucFlowCtrlRcvEn,
//	                                               unsigned char ucFlowCtrlTransEn,
//	                                               unsigned int  uiPauseTime,
//	                                               unsigned char ucDeviceID)
// Description:   	Initiate a control frame transmission
// Parameters:       
//                  unsigned char ucFlowCtrlRcvEn  : 1-enable flow control frame reception  0-diaable
//	     						unsigned char ucFlowCtrlTransEn: 1-enable flow control frame transmission  0-diaable
//				    			unsigned int  uiPauseTime      : Pause time
//                  unsigned char ucDeviceID       : channel ID
// Returns:         1-flow control frame transmission complete   0-transmission ongoing 
//******************************************************************
unsigned char FlowCtrlTransmit(unsigned char ucFlowCtrlRcvEn,unsigned char ucFlowCtrlTransEn,
					                     unsigned int uiPauseTime,unsigned char ucDeviceID);

//******************************************************************
// Function name: 	unsigned long FrameTransmit(unsigned char *TransBuffer, 
//	                                            unsigned int ucToWrite,
//	                                            unsigned char dispad,
//	                                            unsigned char discrc,
//	                                            unsigned char ucDeviceID)
// Description:   	Transmit a frame
// Parameters:       
//                  unsigned char *TransBuffer : buffer that stores data for transmission
//	    					  unsigned int ucToWrite     : frame length
//							    unsigned char dispad       : whether autopadding is enable 
//							    unsigned char discrc       : whether CRC-insertion is enable
//                  unsigned char ucDeviceID   : channel ID
// Returns:				0(reserved for upgrade) 
//******************************************************************
unsigned int FrameTransmit(unsigned int *TransBuffer, unsigned int ucToWrite, unsigned char dispad,
					                 unsigned char discrc,unsigned char ucDeviceID);

//******************************************************************
// Function name: 	unsigned int FrameReceive(unsigned char *RcvBuffer,
//	                                          unsigned long *ulRcvStatus,
//	                                          unsigned char ucDeviceID)
// Description:   	Receive a frame
// Parameters:       
//                  unsigned char *RcvBuffer  : buffer that stores data received
//	    					  unsigned int  *ulRcvStatus: status of frame received
//                  unsigned char ucDeviceID  : channel ID
// Returns:				  length of frame received
//******************************************************************
unsigned int FrameReceive(unsigned int *RcvBuffer, unsigned int *ulRcvStatus,unsigned char ucDeviceID);

//******************************************************************
// Function name: 	unsigned int FrameRead(unsigned char *RcvBuffer, 
//	                                       unsigned long *ulRcvStatus,
//	                                       unsigned char ucDeviceID)
// Description:   	Read a frame from driver buffer to user buffer
//                  when interrupt mode is used, this function is valid
// Parameters:       
//                  unsigned char *RcvBuffer  : buffer that stores data received
//						      unsigned long *ulRcvStatus: status of frame received
//                  unsigned char ucDeviceID  : channel ID
// Returns:				  length of frame read
//******************************************************************
unsigned int FrameRead(unsigned char *RcvBuffer, unsigned long *ulRcvStatus,unsigned char ucDeviceID);

#endif

