/**
	*****************************************************************************
	* @file     cmem7_uart.h
	*
	* @brief    CMEM7 uart header file
	*
	*
	* @version  V1.0
	* @date     3. September 2013
	*
	* @note               
	*           
	*****************************************************************************
	* @attention
	*
	* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
	* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
	* TIME. AS A RESULT, CAPITAL-MICRO SHALL NOT BE HELD LIABLE FOR ANY DIRECT, 
	* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
	* FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
	* CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
	*
	* <h2><center>&copy; COPYRIGHT 2013 Capital-micro </center></h2>
	*****************************************************************************
	*/

#ifndef __CMEM7_UART_H
#define __CMEM7_UART_H

#ifdef __cplusplus
 extern "C" {
#endif

#include "cmem7.h"
#include "cmem7_conf.h"
  
#define IS_UART_ALL_PERIPH(PERIPH) (((PERIPH) == UART0) || \
                                     ((PERIPH) == UART1) || \
                                     ((PERIPH) == UART2))

#define UART_StopBits_0_5                 0
#define UART_StopBits_1                   1
#define UART_StopBits_1_5                 2
#define UART_StopBits_2                   3
#define IS_UART_STOPBITS(STOPBITS) (((STOPBITS) == UART_StopBits_1) || \
                                     ((STOPBITS) == UART_StopBits_0_5) || \
                                     ((STOPBITS) == UART_StopBits_2) || \
                                     ((STOPBITS) == UART_StopBits_1_5))

#define UART_Parity_Even                  0
#define UART_Parity_Odd                   1
#define UART_Parity_None                  2
#define IS_UART_PARITY(PARITY) (((PARITY) == UART_Parity_Even) || \
                                 ((PARITY) == UART_Parity_Odd) || \
																 ((PARITY) == UART_Parity_None))										 

#define UART_Int_RxNotEmpty               0x00000001    
#define UART_Int_TxEmpty                  0x00000002
#define UART_Int_TxHalfEmpty              0x00000004
#define UART_Int_TxTimeoutNotEmpty        0x00000008
#define UART_Int_TxTimeoutEmpty           0x00000010
#define UART_Int_RxHalfFull               0x00000020
#define UART_Int_TxFull                   0x00000040
#define UART_Int_ParityError              0x00000080
#define UART_Int_FrameError               0x00000100
#define UART_Int_OverrunError             0x00000200
#define UART_Int_RxThresholdReach         0x00000400
#define UART_Int_All                      0x000007FF

#define IS_UART_INT(INT)        (((INT) != 0) && (((INT) & ~UART_Int_All) == 0))

typedef struct
{
  uint32_t UART_BaudRate;            /*!< Baudrate */																	  
	uint8_t UART_StopBits;             /*!< Specifies the number of stop bits transmitted. */
  uint8_t UART_Parity;               /*!< Specifies the parity mode. */
	BOOL UART_LoopBack;                /*!< loop back mode */
	BOOL UART_RxEn;                    /*!< receive enable bit */
	BOOL UART_CtsEn;                   /*!< Clear to set */
} UART_InitTypeDef;

void UART_Init(UART0_Type* UARTx, UART_InitTypeDef *init);
void UART_EnableInt(UART0_Type* UARTx, uint32_t Int, BOOL enable);
void UART_Enable(UART0_Type* UARTx, BOOL enable);
BOOL UART_GetIntStatus(UART0_Type* UARTx, uint32_t Int);
void UART_ClearInt(UART0_Type* UARTx, uint32_t Int);
/* return value is actual write data size */
uint8_t UART_Write(UART0_Type* UARTx, uint8_t Size, uint8_t* Data);
/* return value is actual read data size */
uint8_t UART_Read(UART0_Type* UARTx, uint8_t Size, uint8_t* Data);


#ifdef __cplusplus
}
#endif

#endif /* __CMEM7_UART_H */

