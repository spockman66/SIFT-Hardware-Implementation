/**
  * This case is used to move data by DMA and FP, from and to DDRC
	* Hardware :
  **/
	
#include <stdio.h>
#include <string.h>
#include "cmem7_includes.h"



int main(void)
{
	{
	  UART_InitTypeDef init;
	
		init.UART_BaudRate = 115200;
		init.UART_StopBits = UART_StopBits_1; 
		init.UART_Parity = UART_Parity_None;  
		init.UART_LoopBack = FALSE;
		init.UART_RxEn = FALSE; 
		init.UART_CtsEn = FALSE;	
		UART_Init(UART2, &init);
		UART_Enable(UART2, TRUE);
		
		GPIO_Init(GPIO_GROUP_GPIO, 0xFFFFFFFF);
	  GPIO_EnableOutput(GPIO_GROUP_GPIO, 0xFFFFF1FF);
	}

  printf("\n\n/******************************\\\n");
	printf("Init done !!!\n");

	if (1) { //test FP1 slave FIFO space, arm as write, fp as read.
		uint32_t srcAddr = 0xc0000000;
		uint32_t cmdAddrStatusReg = 0xc0000024;
		uint32_t cmdAddrWrCntReg = 0xc0000028;
		uint32_t cmdAddrCtrlReg = 0xc000002c;
		uint32_t addr;
		uint32_t i, data, tmp1, tmp2, gpio_value;
		
		uint32_t status;
		uint32_t wrcnt;

		i=0;
		addr = srcAddr;
		
		printf("\nTest external FP1 slave FIFO space, and make sure FIFO being Empty before write !!!\n");
		
			*((volatile uint32_t *)cmdAddrCtrlReg) = 4; //assert "wclr" signal of FIFO
			*((volatile uint32_t *)cmdAddrCtrlReg) = 0;

     gpio_value = GPIO_Read(GPIO_GROUP_GPIO);
		 gpio_value = (gpio_value >> 9)& 0x00000007;
		

	if (gpio_value == 0x5) {
    
     printf("\nNow get the FIFO status is empty and ARM begins to write!\n");		
		 addr = srcAddr;
		 for(i=0; i<512; i++) {
			 tmp1 = ~addr;
			 tmp2 = addr;
			 data = ((tmp2 << 25) & 0xf8000000) | ((tmp1 << 16) & 0x07fc0000) | ((tmp2 << 7) & 0x0003fe00) | ((tmp2 >> 2) & 0x000001ff);
			 *((volatile uint32_t *)addr) = data;
			 status = *((volatile uint32_t *)cmdAddrStatusReg);
			 wrcnt = *((volatile uint32_t *)cmdAddrWrCntReg);
		   printf("Write 0x%x, then status_r:%x, wrcnt_r:%x\n", addr, status, wrcnt);

			//addr += 4;
		}
		printf("\nARM write done !");		
		status = *((volatile uint32_t *)cmdAddrStatusReg);
	}	
}
	
	printf("\nEND, All functions are OK.\n");
	printf("\\******************************/\n");
	printf("\n");
	while (1);

}

