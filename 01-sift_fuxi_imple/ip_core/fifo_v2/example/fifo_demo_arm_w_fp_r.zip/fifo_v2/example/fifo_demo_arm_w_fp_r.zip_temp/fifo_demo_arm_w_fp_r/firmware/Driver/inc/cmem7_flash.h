/**
	*****************************************************************************
	* @file     cmem7_flash.h
	*
	* @brief    CMEM7 flash controller source file
	*
	*
	* @version  V1.0
	* @date     3. September 2013
	*
	* @note               
	*           
	*****************************************************************************
	* @attention
	*
	* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
	* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
	* TIME. AS A RESULT, CAPITAL-MICRO SHALL NOT BE HELD LIABLE FOR ANY DIRECT, 
	* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
	* FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
	* CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
	*
	* <h2><center>&copy; COPYRIGHT 2013 Capital-micro </center></h2>
	*****************************************************************************
	*/
	
#ifndef __CMEM7_FLASH_H
#define __CMEM7_FLASH_H

#ifdef __cplusplus
 extern "C" {
#endif

#include "cmem7.h"
#include "cmem7_conf.h"

#define FLASH_PROTECT_MODE_SW           0       /*!< The Status Register can be written to after a Write 
                                                     Enable command.(Default) */
#define FLASH_PROTECT_MODE_HW           1       /*!< WP pin decides if the Status Register can be written 
                                                     WP#=0, the Status Register locked
																									   WP#=1, the Status Register is unlocked and can be written to
                                                     after a Write Enable command */
#define FLASH_PROTECT_MODE_POWERDOWN    2				/*!< Status Register is protected and can not be written to again
                                                     until the next Power-Down, Power-Up cycle */	
#define FLASH_PROTECT_MODE_OTP          3       /*!< Status Register is permanently protected */	

#define IS_FLASH_PROTECT_MODE(MODE)     (((MODE) == FLASH_PROTECT_MODE_SW) || \
                                         ((MODE) == FLASH_PROTECT_MODE_HW) || \
                                         ((MODE) == FLASH_PROTECT_MODE_POWERDOWN) || \
                                         ((MODE) == FLASH_PROTECT_MODE_OTP))

#define FLASH_PROTECT_REGION_NONE       0x00    /*!< no region is protected */
#define FLASH_PROTECT_REGION_UP_64K     0x01    /*!< region(0F0000H-0FFFFFH) is protected */
#define FLASH_PROTECT_REGION_UP_128K    0x02    /*!< region(0E0000H-0FFFFFH) is protected */
#define FLASH_PROTECT_REGION_UP_256K    0x03    /*!< region(0C0000H-0FFFFFH) is protected */
#define FLASH_PROTECT_REGION_UP_512K    0x04    /*!< region(080000H-0FFFFFH) is protected */
#define FLASH_PROTECT_REGION_LOW_64K    0x09    /*!< region(000000H-00FFFFH) is protected */
#define FLASH_PROTECT_REGION_LOW_128K   0x0A    /*!< region(000000H-01FFFFH) is protected */
#define FLASH_PROTECT_REGION_LOW_256K   0x0B    /*!< region(000000H-03FFFFH) is protected */
#define FLASH_PROTECT_REGION_LOW_512K   0x0C    /*!< region(000000H-07FFFFH) is protected */
#define FLASH_PROTECT_REGION_ALL        0x0D    /*!< region(000000H-0FFFFFH) is protected */
#define FLASH_PROTECT_REGION_UP_4K      0x11    /*!< region(0FF000H-0FFFFFH) is protected */
#define FLASH_PROTECT_REGION_UP_8K      0x12    /*!< region(0FE000H-0FFFFFH) is protected */
#define FLASH_PROTECT_REGION_UP_16K     0x13    /*!< region(0FC000H-0FFFFFH) is protected */
#define FLASH_PROTECT_REGION_UP_32K     0x14    /*!< region(0F8000H-0FFFFFH) is protected */
#define FLASH_PROTECT_REGION_LOW_4K     0x19    /*!< region(000000H-000FFFH) is protected */
#define FLASH_PROTECT_REGION_LOW_8K     0x1A    /*!< region(000000H-001FFFH) is protected */
#define FLASH_PROTECT_REGION_LOW_16K    0x1B    /*!< region(000000H-003FFFH) is protected */
#define FLASH_PROTECT_REGION_LOW_32K    0x1C    /*!< region(000000H-007FFFH) is protected */

#define IS_FLASH_PROTECT_REGION(REGION) (((REGION) == FLASH_PROTECT_REGION_NONE) || \
                                         ((REGION) == FLASH_PROTECT_REGION_UP_64K) || \
                                         ((REGION) == FLASH_PROTECT_REGION_UP_128K) || \
																				 ((REGION) == FLASH_PROTECT_REGION_UP_256K) || \
																				 ((REGION) == FLASH_PROTECT_REGION_UP_512K) || \
																				 ((REGION) == FLASH_PROTECT_REGION_LOW_64K) || \
                                         ((REGION) == FLASH_PROTECT_REGION_LOW_128K) || \
																				 ((REGION) == FLASH_PROTECT_REGION_LOW_256K) || \
																				 ((REGION) == FLASH_PROTECT_REGION_LOW_512K) || \
																				 ((REGION) == FLASH_PROTECT_REGION_ALL) || \
                                         ((REGION) == FLASH_PROTECT_REGION_UP_4K) || \
                                         ((REGION) == FLASH_PROTECT_REGION_UP_8K) || \
																				 ((REGION) == FLASH_PROTECT_REGION_UP_16K) || \
																				 ((REGION) == FLASH_PROTECT_REGION_UP_32K) || \
																				 ((REGION) == FLASH_PROTECT_REGION_LOW_4K) || \
                                         ((REGION) == FLASH_PROTECT_REGION_LOW_8K) || \
																				 ((REGION) == FLASH_PROTECT_REGION_LOW_16K) || \
																				 ((REGION) == FLASH_PROTECT_REGION_LOW_32K))

#define FLASH_READ_MODE_NORMAL         0        /*!< normal read, 1 bitwidth, highest freqency is 90MHz */
#define FLASH_READ_MODE_FAST           1        /*!< fast read, 1 bitwidth, highest freqency is 120MHz */
#define FLASH_READ_MODE_FAST_DUAL      2        /*!< fast read, 2 bitwidth, highest freqency is 120MHz */
#define FLASH_READ_MODE_FAST_QUAD      3        /*!< fast read, 4 bitwidth, highest freqency is 90MHz */

#define IS_FLASH_READ_MODE(MODE)       (((MODE) == FLASH_READ_MODE_NORMAL) || \
                                        ((MODE) == FLASH_READ_MODE_FAST) || \
                                        ((MODE) == FLASH_READ_MODE_FAST_DUAL) || \
																				((MODE) == FLASH_READ_MODE_FAST_QUAD))
																									

typedef struct
{
  uint8_t FLASH_ClockDividor;       /*!< flash clock dividor, 2 in n times */
	uint8_t FLASH_ProtectMode;        /*!< Status Register protection mode */
	uint8_t FLASH_ProtectRegion;      /*!< flash protection region */
	BOOL FLASH_QuadEnable;            /*!< if allows Quad operation */
	void (*FLASH_Wait)(void);         /*!< When the former read or write operation is excuting, 
	                                       Flash has to call a callback to wait it finish. 
	                                       If null, Flash will wait forever until finish */
} FLASH_InitTypeDef;




/** User should make sure that doesn't write data at a 
    write-protected address. It does nothing */
void FLASH_Init(FLASH_InitTypeDef* init);
void FLASH_GetStatus(uint8_t* ProtectMode, uint8_t* ProtectRegion, BOOL* QuadEnable);
void FLASH_EraseSector(uint32_t addr);
void FLASH_Erase32kBlock(uint32_t addr);
void FLASH_Erase64kBlock(uint32_t addr);
void FLASH_EraseChip(void);
void FLASH_EnableDeepPowerDown(BOOL enable);
void FLASH_Read(uint8_t ReadMode, uint32_t addr, uint16_t size, uint8_t* data);
void FLASH_Write(uint32_t addr, uint16_t size, uint8_t* data);

#ifdef __cplusplus
}
#endif

#endif /* __CMEM7_FLASH_H */

