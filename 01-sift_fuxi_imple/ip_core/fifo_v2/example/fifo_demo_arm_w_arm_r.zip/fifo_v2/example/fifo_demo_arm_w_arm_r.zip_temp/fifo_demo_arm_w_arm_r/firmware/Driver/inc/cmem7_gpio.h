/**
	*****************************************************************************
	* @file     cmem7_gpio.h
	*
	* @brief    CMEM7 GPIO header file
	*
	*
	* @version  V1.0
	* @date     3. September 2013
	*
	* @note               
	*           
	*****************************************************************************
	* @attention
	*
	* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
	* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
	* TIME. AS A RESULT, CAPITAL-MICRO SHALL NOT BE HELD LIABLE FOR ANY DIRECT, 
	* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
	* FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
	* CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
	*
	* <h2><center>&copy; COPYRIGHT 2013 Capital-micro </center></h2>
	*****************************************************************************
	*/
	
#ifndef __CMEM7_GPIO_H
#define __CMEM7_GPIO_H

#ifdef __cplusplus
 extern "C" {
#endif

#include "cmem7.h"
#include "cmem7_conf.h"

typedef enum {
	GPIO_GROUP_GPIO,
	GPIO_GROUP_GPIO_H,
	GPIO_GROUP_GPIO_N,
} GPIO_GROUP;

#define IS_GPIO_GROUP(GROUP)  (((GROUP) == GPIO_GROUP_GPIO) || \
                               ((GROUP) == GPIO_GROUP_GPIO_H) || \
                               ((GROUP) == GPIO_GROUP_GPIO_N))

typedef enum {
	GPIO_PWM_CHANNEL_GPIO_31,
	GPIO_PWM_CHANNEL_GPIO_H_9,
	GPIO_PWM_CHANNEL_GPIO_H_19,
	GPIO_PWM_CHANNEL_GPIO_H_20,
} GPIO_PWM_CHANNEL;
        
#define IS_GPIO_PWM_CHANNEL(CHANNEL)  (((CHANNEL) == GPIO_PWM_CHANNEL_GPIO_31) || \
                                       ((CHANNEL) == GPIO_PWM_CHANNEL_GPIO_H_9) || \
                                       ((CHANNEL) == GPIO_PWM_CHANNEL_GPIO_H_19) || \
                                       ((CHANNEL) == GPIO_PWM_CHANNEL_GPIO_H_20))

void GPIO_Init(uint8_t Group, uint32_t PositiveTrigger);
void GPIO_EnableOutput(uint8_t Group, uint32_t Enable);
void GPIO_EnableInt(uint8_t Group, uint32_t Enable);
uint32_t GPIO_GetIntStatus(uint8_t Group);
void GPIO_ClearInt(uint8_t Group, uint32_t Clear);
uint32_t GPIO_Read(uint8_t Group);
void GPIO_Write(uint8_t Group, uint32_t Unmask, uint32_t data);
void GPIO_InitPwm(uint8_t Channel, uint32_t HighLevelNanoSecond, uint32_t LowLevelNanoSecond);
void GPIO_EnablePwm(uint8_t Channel, BOOL Enable);

#ifdef __cplusplus
}
#endif

#endif /* __CMEM7_GPIO_H */

