/**
  * This case is used to move data by DMA and FP, from and to DDRC
	* Hardware :
  **/
	
#include <stdio.h>
#include <string.h>
#include "cmem7_includes.h"

uint32_t is_FULL;
uint32_t is_EMPTY;
uint32_t is_prog_FULL;
uint32_t is_prog_EMPTY;
uint32_t is_almost_FULL;
uint32_t is_almost_EMPTY;

//  void FP0_IRQHandler(void)
//  {
//  	printf("has interrupt");	
//  }

int main(void)
{
		
	{
	 
		UART_InitTypeDef init;
	
		init.UART_BaudRate = 115200;
		init.UART_StopBits = UART_StopBits_1; 
		init.UART_Parity = UART_Parity_None;  
		init.UART_LoopBack = FALSE;
		init.UART_RxEn = FALSE; 
		init.UART_CtsEn = FALSE;	
		UART_Init(UART2, &init);
		UART_Enable(UART2, TRUE);
	}

	{
		NVIC_InitTypeDef NVIC_InitStructure;

		/* Configure the NVIC Preemption Priority Bits */  
		NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
		
		/* Enable the FP0 Interrupt */
		NVIC_InitStructure.NVIC_IRQChannel = FP0_INT_IRQn;
		NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
		NVIC_InitStructure.NVIC_IRQChannelCmd = TRUE;
	//NVIC_InitStructure.NVIC_IRQChannelCmd = FALSE;
		NVIC_Init(&NVIC_InitStructure);
		
	}
	
  printf("\n\n/******************************\\\n");
	printf("Init done !!!\n");

	if (1) {
		uint32_t srcAddr = 0xc0000000;
		uint32_t cmdAddrIntEnableReg = 0xc0000020;
		uint32_t cmdAddrRtrlReg = 0xc000001c;

		
		uint32_t data,i;
		
		is_FULL = 0;
		is_EMPTY = 0;
		
		i = 0;

		
		printf("\n Now enable write interrupt and begin to write data to FIFO !\n");
		*((volatile uint32_t *)cmdAddrRtrlReg) = 0x1;        // enable interrupt in FP
		*((volatile uint32_t *)cmdAddrIntEnableReg) = 0x15;  // enable write interrupt
	
		
		while(!is_FULL){
			for(i=0; i<512; i++) {
			*((volatile uint32_t *)srcAddr) = i;
				udelay(100);
		 }
		  	
	}
	
	  
	  printf("\n Write done! Now enable read interrupt and begin to read data from FIFO !\n");
	  *((volatile uint32_t *)cmdAddrIntEnableReg) = 0x2a;
	
	   while(!is_EMPTY){

			for(i=0; i<512; i++) {
			   data = *(uint32_t *)srcAddr;
			   if(data != i) {
				    printf("ARM write-read FP1-slave FAILED @0x%x: 0x%x!=0x%x!\n", srcAddr, data, i);
		   }
	}
}
 	printf("\n Read end,and compare the data is OK.\n");
  printf("\nEND, All functions are OK.\n");
  printf("\\******************************/\n");
  printf("\n");
  *((volatile uint32_t *)cmdAddrRtrlReg) = 0;
  while (1);
		
	}
}
	


