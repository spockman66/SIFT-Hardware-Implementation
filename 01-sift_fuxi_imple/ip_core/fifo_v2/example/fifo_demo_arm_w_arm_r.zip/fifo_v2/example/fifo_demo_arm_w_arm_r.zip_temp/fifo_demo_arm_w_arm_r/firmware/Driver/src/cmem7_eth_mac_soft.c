//================================================================================
// Copyright (c) 2012 Capital-micro, Inc.(Beijing)  All rights reserved.
//
// Capital-micro, Inc.(Beijing) Confidential.
//
// No part of this code may be reproduced, distributed, transmitted,
// transcribed, stored in a retrieval system, or translated into any
// human or computer language, in any form or by any means, electronic,
// mechanical, magnetic, manual, or otherwise, without the express
// written permission of Capital-micro, Inc.
//
//================================================================================
// File Description: 
// Code for Ethernet MAC soft IP in M7A 
//================================================================================
// Revision History :
//     V1.0   2013-04-11  FPGA IP Grp, first created
//     V1.1   2013-10-15  FPGA IP Grp, PHY Configuration & Status Read modified
//     V2.0   2014-01-20  FPGA IP Grp, modify architecture of transmitting & receiving
//                                     buffer, only support M7A  
//================================================================================

//  Include section
#include "cmem7_eth_mac_soft.h"
// #include "cmem7_dma.h"
#include "cmem7_includes.h"

#define MAC_TX_DMA
#define MAC_RX_DMA
//******************************************************************
//            Register Declaration
//******************************************************************
BOOL isDone = FALSE;
unsigned char ram_sel = 0;
// ******************************************************************************
// *** For application with interrupt, RcvFrameBuf should be assigned by user, **
// *********** so new frame data can be moved to user buffer directly. **********

// unsigned char RcvFrameBuf[1550];
// unsigned long RcvStatus;
// unsigned int  RcvLength;
// *****************************************************************
//  Interrupt Handle
// void EthernetMacIrq(void) interrupt 1
// {
//    RcvLength = FrameReceive(RcvFrameBuf,RcvStatus);
// }
// *****************************************************************

void PhyRegWrite(unsigned char ucPhyAddr,unsigned char ucPhyRegAddr,
					  unsigned char ucClkDivide,unsigned int uiDataToWrite,
					  unsigned char ucDeviceID)
{
	unsigned int  uiDataTmp = 0;

	uiDataTmp = PHY_ACCESS_ADDR(ucDeviceID);
	while((uiDataTmp & 0x1) == 0x1)
	{   
	   uiDataTmp = PHY_ACCESS_ADDR(ucDeviceID);
   }
	uiDataTmp = uiDataToWrite;
   PHY_ACCESS_DATA(ucDeviceID)  = uiDataTmp;

	uiDataTmp = (((unsigned int)ucPhyAddr) << 11) | (((unsigned int)ucPhyRegAddr) << 6) | (((unsigned int)ucClkDivide) << 2) | 0x3;
   PHY_ACCESS_ADDR(ucDeviceID)  = uiDataTmp;

	uiDataTmp = PHY_ACCESS_ADDR(ucDeviceID);
	while((uiDataTmp & 0x1) == 0x1)
	{   
	   uiDataTmp = PHY_ACCESS_ADDR(ucDeviceID);
   }
}

unsigned int PhyRegRead(unsigned char ucPhyAddr,unsigned char ucPhyRegAddr,
					         unsigned char ucClkDivide,unsigned char ucDeviceID)
{
	unsigned int  uiDataTmp = 0;

	uiDataTmp = PHY_ACCESS_ADDR(ucDeviceID);
	while((uiDataTmp & 0x1) == 0x1)
	{   
	   uiDataTmp = PHY_ACCESS_ADDR(ucDeviceID);
   }
	uiDataTmp = (((unsigned int)ucPhyAddr) << 11) | (((unsigned int)ucPhyRegAddr) << 6) | (((unsigned int)ucClkDivide) << 2) | 0x1;
   PHY_ACCESS_ADDR(ucDeviceID)  = uiDataTmp;

	uiDataTmp = PHY_ACCESS_ADDR(ucDeviceID);
	while((uiDataTmp & 0x1) == 0x1)
	{   
	   uiDataTmp = PHY_ACCESS_ADDR(ucDeviceID);
   }
	uiDataTmp = PHY_ACCESS_DATA(ucDeviceID);
	return uiDataTmp;
}

unsigned char LinkCheck(unsigned char ucDeviceID)
{
	unsigned int  uiDataTmp;

	PhyRegRead(PHY_ADDR,PHY_STATUS_ADDR,CSR_CLK_DV,ucDeviceID);
	uiDataTmp =  PhyRegRead(PHY_ADDR,PHY_STATUS_ADDR,CSR_CLK_DV,ucDeviceID);
   uiDataTmp &= 0x4;

	if(uiDataTmp == 0x4)
		return 1;
	else
		return 0;	  
}

void PhyMannualSpeedDuplexSet(unsigned char ucSpeed,unsigned char ucDuplex,
					               unsigned char ucDeviceID)    
{
   unsigned int  uiDataTmp;
	unsigned char ucDataTmp;
	
	uiDataTmp = PhyRegRead(PHY_ADDR,PHY_CTRL_ADDR,CSR_CLK_DV,ucDeviceID); 
	if(ucSpeed==0)
	{	
		 if(ucDuplex)
		 {
			 uiDataTmp = 0x140;
			 PhyRegWrite(PHY_ADDR,PHY_CTRL_ADDR,CSR_CLK_DV,uiDataTmp,ucDeviceID); 
		 }
		 else
     {
			 uiDataTmp = 0x40;
			 PhyRegWrite(PHY_ADDR,PHY_CTRL_ADDR,CSR_CLK_DV,uiDataTmp,ucDeviceID); 
		 }
	}
   else if(ucSpeed==1)	
   {	
		 if(ucDuplex)
		 {
			 uiDataTmp = 0x2100;
			 PhyRegWrite(PHY_ADDR,PHY_CTRL_ADDR,CSR_CLK_DV,uiDataTmp,ucDeviceID); 
		 }
		 else
     {
			 uiDataTmp = 0x2000;
			 PhyRegWrite(PHY_ADDR,PHY_CTRL_ADDR,CSR_CLK_DV,uiDataTmp,ucDeviceID); 
		 }
	}
	else if(ucSpeed==2)	
	{	
		 if(ucDuplex)
		 {
			 uiDataTmp = 0x100;
			 PhyRegWrite(PHY_ADDR,PHY_CTRL_ADDR,CSR_CLK_DV,uiDataTmp,ucDeviceID); 
		 }
		 else
     {
			 uiDataTmp = 0x0;
			 PhyRegWrite(PHY_ADDR,PHY_CTRL_ADDR,CSR_CLK_DV,uiDataTmp,ucDeviceID); 
		 }
	}	
	uiDataTmp = uiDataTmp | 0x8000;
	PhyRegWrite(PHY_ADDR,PHY_CTRL_ADDR,CSR_CLK_DV,uiDataTmp,ucDeviceID); 
	ucDataTmp = LinkCheck(ucDeviceID);
	while(!ucDataTmp)
	{	
		ucDataTmp = LinkCheck(ucDeviceID);
	}	
}

unsigned char PhyInitial(unsigned char *ucANst,unsigned char *ucSpeedSt,
					          unsigned char *ucDuplexSt,unsigned char ucDeviceID)
{
   unsigned int  uiDataTmp;
	unsigned char ucDataTmp;
// 	unsigned char ucSpeedDuplex = 0;

//------------ write (AN enable & restart AN) to PHY -------------------
	uiDataTmp = PhyRegRead(PHY_ADDR,PHY_CTRL_ADDR,CSR_CLK_DV,ucDeviceID); 
   uiDataTmp = uiDataTmp | 0x1200;         // AN enable & restart AN
	PhyRegWrite(PHY_ADDR,PHY_CTRL_ADDR,CSR_CLK_DV,uiDataTmp,ucDeviceID); 
	PhyRegRead(PHY_ADDR,PHY_CTRL_ADDR,CSR_CLK_DV,ucDeviceID);

//------- read BMSR to check whether AN is over or not -----------------
   uiDataTmp = 0;
	while((uiDataTmp & 0x20) != 0x20)
	{		  
		uiDataTmp = PhyRegRead(PHY_ADDR,PHY_STATUS_ADDR,CSR_CLK_DV,ucDeviceID);
   }
//----------------- Check link is up or down  --------------------------
	ucDataTmp = LinkCheck(ucDeviceID);
	if(!ucDataTmp)
		return 0;	 

//--------------- check Auto Negotiation is used ----------------------
	uiDataTmp = PhyRegRead(PHY_ADDR,PHY_AN_ADDR,CSR_CLK_DV,ucDeviceID);
   ucDataTmp = ((unsigned char)uiDataTmp) & 0x1;
	if(ucDataTmp == 0x1)
		*ucANst = 0x1;
	else
		*ucANst = 0;
	
	uiDataTmp = PhyRegRead(PHY_ADDR,PHY_SPEED_DUPLEX_ADDR,CSR_CLK_DV,ucDeviceID); 
	while((uiDataTmp & 0xc00) != 0xc00)
	{
		uiDataTmp = PhyRegRead(PHY_ADDR,PHY_SPEED_DUPLEX_ADDR,CSR_CLK_DV,ucDeviceID); 
	}
	
	if((uiDataTmp & 0xC000) == 0x8000)
		ucDataTmp = 0x4;
	else if((uiDataTmp & 0xC000) == 0x4000)
		ucDataTmp = 0x2;
	else if((uiDataTmp & 0xC000) == 0)
		ucDataTmp = 0x1;
	else
	{
		ucDataTmp = 0;
		return 0;	
	}	
	*ucSpeedSt = 	ucDataTmp;
	
	if((uiDataTmp & 0x2000) == 0x2000)
		ucDataTmp = 1;
	else
		ucDataTmp = 0;
	*ucDuplexSt = ucDataTmp;

	return 1;
}

void MACCtrlInitial(unsigned char ucSpeed,unsigned char ucDuplex,
					     unsigned char ucTransEn,unsigned char ucRcvEn,
						  unsigned char ucLoopBack,unsigned char ucACS,
                    unsigned char ucCST,unsigned char ucDeviceID)
{
	unsigned char ucDataTmp = 0;
	unsigned int  uiDataTmp = 0;

	ucDataTmp  = (ucACS<<7) | (ucTransEn<<3) | (ucRcvEn<<2);
	uiDataTmp  = (unsigned int)ucDataTmp;
   ucDataTmp  = (ucSpeed<<7) | (ucLoopBack<<4) | (ucDuplex<<3);	
   uiDataTmp |= (((unsigned int)ucDataTmp) << 8);	
	ucDataTmp  = ucCST<<1;
   uiDataTmp |= (((unsigned int)ucDataTmp) << 24);	
	MAC_CFG(ucDeviceID)    = uiDataTmp;	///////////////////////////////////////////////////////////////////////////
}

void MACAddressInitial(unsigned char *mac_addr,unsigned char ucDeviceID)
{
   unsigned int uiDataTmp = 0;

   MAC_ADDR_H(ucDeviceID) = ((*(mac_addr+5))<<8) | (*(mac_addr+4)) ;
   uiDataTmp |= (unsigned int)(*mac_addr++);
   uiDataTmp |= ((unsigned int)(*mac_addr++)) << 8;
   uiDataTmp |= ((unsigned int)(*mac_addr++)) << 16;
   uiDataTmp |= ((unsigned int)(*mac_addr)) << 24;
   MAC_ADDR_L(ucDeviceID) = uiDataTmp;
}

void FrameRcvFilterInitial(unsigned char ucRvcAll,unsigned char ucVLANFilterEn,
					            unsigned char ucPassCtrl,unsigned char ucDisBroadcast,
									unsigned char ucPassMulticast,unsigned char ucDeviceID)
{
	unsigned int  uiDataTmp = 0;

	uiDataTmp |= (((unsigned long)ucRvcAll) << 31);
	uiDataTmp |= (((unsigned long)ucVLANFilterEn) << 16);
	uiDataTmp |= (((unsigned long)ucPassCtrl) << 6);
	uiDataTmp |= (((unsigned long)ucDisBroadcast) << 5);
	uiDataTmp |= (((unsigned long)ucPassMulticast) << 4);
	FRAME_FILTER(ucDeviceID) = uiDataTmp;
}

void FlowCtrlInitial(unsigned char ucFlowCtrlRcvEn,unsigned char ucFlowCtrlTransEn,
					      unsigned char ucDeviceID)
{
   unsigned int uiDataTmp = 0;

	uiDataTmp = FLOW_CTRL(ucDeviceID);
	while((uiDataTmp & 0x1) == 0x1)
	{   
	   uiDataTmp = FLOW_CTRL(ucDeviceID);
   }
	uiDataTmp   = 0;
	uiDataTmp  |= (unsigned int)((ucFlowCtrlRcvEn << 2) | (ucFlowCtrlTransEn << 1));
  	FLOW_CTRL(ucDeviceID)   = uiDataTmp;
}

void VLANTagInitial(unsigned int TagData,unsigned char ucDeviceID)
{
   VLAN_TAG(ucDeviceID) = TagData;	
}

unsigned char FlowCtrlTransmit(unsigned char ucFlowCtrlRcvEn,unsigned char ucFlowCtrlTransEn,
					                unsigned int uiPauseTime,unsigned char ucDeviceID)
{
   unsigned int  uiDataTmp = 0;
   unsigned char ucDataTmp = 0;

	uiDataTmp = FLOW_CTRL(ucDeviceID);
	while((uiDataTmp & 0x1) == 0x1)
	{   
	   uiDataTmp = FLOW_CTRL(ucDeviceID);
   }
	if(!ucFlowCtrlTransEn)
		return 0;
	else
	   uiDataTmp = (uiPauseTime << 16) & 0xffff0000;
	
	ucDataTmp  = (ucFlowCtrlRcvEn << 2) | (ucFlowCtrlTransEn << 1) | 0x1;
   uiDataTmp |= (unsigned int)ucDataTmp;
	FLOW_CTRL(ucDeviceID)  = uiDataTmp;

	while((uiDataTmp & 0x1) == 0x1)
	{   
	   uiDataTmp = FLOW_CTRL(ucDeviceID);
   }
	return 1;
}

unsigned int FrameTransmit(unsigned int *TransBuffer, unsigned int uiToWrite,
                           unsigned char dispad, unsigned char discrc,
									unsigned char ucDeviceID)
{
  unsigned int  uiDataTmp,uiDataTmp_0;
  unsigned int  i,frame_dword_len;
  unsigned int  uiTxRAMAddr;
	unsigned int  srcAddr;
	unsigned int  dstAddr;
	unsigned int  BlockSize;
	unsigned char ram_sel_channel;
	BLOCK_DESC    bp;
	
	if(ucDeviceID == 0)
		 ram_sel_channel = 0x1;
	else
	   ram_sel_channel = 0x2;	
	
	if(!(ram_sel & ram_sel_channel))
  {	
     uiDataTmp = MEM_STATUS(ucDeviceID) & 0x4;
	  while(uiDataTmp != 0)
	  {	
		 uiDataTmp = MEM_STATUS(ucDeviceID) & 0x4;
		 uiDataTmp_0 = *((volatile int*)(0xa0001054));		
     }
	  MEM_STATUS(ucDeviceID) &= 0xef;
  }
  else
  {	
	  uiDataTmp = MEM_STATUS(ucDeviceID) & 0x8;
	  while(uiDataTmp != 0)
	  {	
	    uiDataTmp = MEM_STATUS(ucDeviceID) & 0x8;
			uiDataTmp_0 = *((volatile int*)(0xa0001054));	
     }
	  MEM_STATUS(ucDeviceID) |= 0x10;
  }
			
  uiTxRAMAddr = 0;
  REG(ucDeviceID, uiTxRAMAddr) = uiToWrite;
	uiDataTmp   = uiToWrite % 4;
  if(uiDataTmp == 0)
    frame_dword_len = uiToWrite / 4;
  else
    frame_dword_len = ((uiToWrite - uiDataTmp) / 4) + 1;
	
#ifdef MAC_TX_DMA	
	srcAddr = (unsigned int)TransBuffer;
	dstAddr = BASE_ADDR_SOFT_MAC + ucDeviceID * 0x2000 + 4;	
	BlockSize = frame_dword_len;
  
								
	bp.srcAddr = srcAddr;
	bp.dstAddr = dstAddr;
	bp.number  = BlockSize;
	bp.nextBlock = 0;
				
	isDone = FALSE;
	DMA_Transfer(&bp);
  while (!isDone) ;	  
#else
	uiTxRAMAddr = uiTxRAMAddr + 4;		
  for (i=0; i<frame_dword_len; i++ )
  {
    REG(ucDeviceID, uiTxRAMAddr) = *TransBuffer;
		TransBuffer++;
    uiTxRAMAddr = uiTxRAMAddr + 4;
  }
#endif	

  if(!(ram_sel & ram_sel_channel))
    MEM_CONFIG(ucDeviceID) = 0x31;
  else
    MEM_CONFIG(ucDeviceID) = 0x41;
	
  if(ucDeviceID == 0)
		 ram_sel = ram_sel ^ 0x1;
	else
	   ram_sel = ram_sel ^ 0x2;

}

unsigned int FrameReceive(unsigned int *RcvBuffer, unsigned int *uiRcvStatus,
					           unsigned char ucDeviceID)
{
  unsigned int  uiDataTmp;
  unsigned int  uiRcvLength = 0;
  unsigned int  i,frame_dword_len;
	unsigned int  srcAddr;
	unsigned int  dstAddr;
	unsigned int  BlockSize;
	BLOCK_DESC    bp;
	
  uiDataTmp = MEM_STATUS(ucDeviceID) & 0x20;
  if(uiDataTmp == 0x0)
  {
    return 0;
  }
  uiRcvLength = RCV_LEN(ucDeviceID);
	
#ifdef MAC_RX_DMA	
	uiDataTmp   = uiRcvLength % 4;
  if(uiDataTmp == 0)
    frame_dword_len = uiRcvLength / 4;
  else
    frame_dword_len = ((uiRcvLength - uiDataTmp) / 4) + 1;
	
  srcAddr = BASE_ADDR_SOFT_MAC + ucDeviceID * 0x2000 + 0x800;	
	dstAddr = (unsigned int)RcvBuffer;
	BlockSize = frame_dword_len;
  							
	bp.srcAddr = srcAddr;
	bp.dstAddr = dstAddr;
	bp.number  = BlockSize;
	bp.nextBlock = 0;
				
	isDone = FALSE;
	DMA_Transfer(&bp);
  while (!isDone) ;		
	
#else	
  i = 0;
  while(i<uiRcvLength)
  {
	  *RcvBuffer = REG(ucDeviceID,0x800 + i);
    RcvBuffer++;
	  i = i + 4;
  }
#endif
	
  *uiRcvStatus= RCV_STATUS(ucDeviceID);
  MEM_CONFIG(ucDeviceID)   = 0x51;

  return uiRcvLength;
}












